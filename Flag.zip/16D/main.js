var height = window.innerHeight * 2
var flag = document.querySelector('.flag')

window.onscroll = function(){
	var sv = Math.min(height, window.scrollY)
	var p = (sv / height) * 100
	flag.style.bottom = p + '%'
	flag.style.transform = "translateY(" + p + '%)'
}